#!/bin/bash

python automated_redistricting.py
cp -r ../AutomatedRedistricting/ /home/reka/.qgis2/python/plugins
