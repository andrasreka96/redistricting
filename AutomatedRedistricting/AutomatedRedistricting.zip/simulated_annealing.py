import math

class simulated_annealing:
    def p(f,X,Y):
        return exp()
    def sa(temperature,f,initial_solutin):
